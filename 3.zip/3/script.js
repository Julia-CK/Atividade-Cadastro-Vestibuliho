document.addEventListener('DOMContentLoaded', () => {
    const estadoSelect = document.getElementById('estado');
    const municipioSelect = document.getElementById('municipio');

    async function carregarEstados() {
        try {
            const response = await fetch('https://servicodados.ibge.gov.br/api/v1/localidades/estados?orderBy=nome');
            const estados = await response.json();

            estados.forEach(estado => {
                const option = document.createElement('option');
                option.value = estado.sigla; 
                option.textContent = estado.sigla;
                estadoSelect.appendChild(option);
            });
        } catch (error) {
            console.error('Erro ao carregar estados:', error);
        }
    }

   
    async function carregarMunicipios(uf) {
        municipioSelect.innerHTML = '<option value="">Selecione um municipio</option>'; 
        municipioSelect.disabled = true; 
        if (!uf) {
            return; 
        }

        try {
            const response = await fetch(`https://servicodados.ibge.gov.br/api/v1/localidades/estados/${uf}/municipios?orderBy=nome`);
            const municipios = await response.json();

            municipios.forEach(municipio => {
                const option = document.createElement('option');
                option.value = municipio.nome;
                option.textContent = municipio.nome;
                municipioSelect.appendChild(option);
            });
            municipioSelect.disabled = false;
        } catch (error) {
            console.error('Erro ao carregar municipios:', error);
        }
    }

    
    estadoSelect.addEventListener('change', (event) => {
        const ufSelecionada = event.target.value;
        carregarMunicipios(ufSelecionada);
    });

   
    carregarEstados();
});

document.getElementById('cep').addEventListener('input', function(e) {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length > 5) {
        value = value.substring(0, 5) + '-' + value.substring(5, 8);
    }
    e.target.value = value;
});

document.querySelectorAll('.form-select').forEach(select => {
    select.style.width = '100%';
    select.style.maxWidth = '100%';
    select.style.minWidth = '500px';
});
